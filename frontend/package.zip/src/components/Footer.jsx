import React from 'react';
import { Link } from 'react-router-dom';

export default function Footer() {
  const userStr = localStorage.getItem('user');
  const user = userStr ? JSON.parse(userStr) : null;
  const role = user ? user.role : null;

  return (
    <footer className="bg-[#0a0a0a] border-t border-white/10 mt-auto relative z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-sm text-gray-400">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-6 h-6 rounded bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-xs font-bold shadow-lg shadow-blue-500/20">
                K
              </div>
              <h4 className="font-bold text-white text-lg tracking-tight">Konnectt</h4>
            </div>
            <p className="text-xs text-gray-500 leading-relaxed">
              Empowering the next generation of workforce with AI-driven connections and decentralized opportunities.
            </p>
          </div>

          {/* Job Seeker Links - Visible to Job Seekers or Guests */}
          {(!role || role === 'jobseeker') && (
            <div>
              <h4 className="font-bold text-white mb-4">For Job Seekers</h4>
              <ul className="space-y-2">
                <li><Link to="/jobs" className="hover:text-blue-400 transition-colors">Browse Jobs</Link></li>
                {role === 'jobseeker' && (
                  <>
                    <li><Link to="/my-applications" className="hover:text-blue-400 transition-colors">My Applications</Link></li>
                    <li><Link to="/profile" className="hover:text-blue-400 transition-colors">My Profile</Link></li>
                  </>
                )}
              </ul>
            </div>
          )}

          {/* Employer Links - Visible to Employers or Guests (limited) */}
          {(!role || role === 'employer') && (
            <div>
              <h4 className="font-bold text-white mb-4">For Employers</h4>
              <ul className="space-y-2">
                {role === 'employer' ? (
                  <>
                    <li><Link to="/post-job" className="hover:text-blue-400 transition-colors">Post a Job</Link></li>
                    <li><Link to="/employer" className="hover:text-blue-400 transition-colors">My Dashboard</Link></li>
                    <li><Link to="/profile" className="hover:text-blue-400 transition-colors">My Profile</Link></li>
                  </>
                ) : (
                  <li><Link to="/login" className="hover:text-blue-400 transition-colors">Post a Job</Link></li>
                )}
              </ul>
            </div>
          )}

          <div>
            <h4 className="font-bold text-white mb-4">Company</h4>
            <ul className="space-y-2">
              <li><Link to="/about" className="hover:text-blue-400 transition-colors">About</Link></li>
              <li><Link to="/contact" className="hover:text-blue-400 transition-colors">Contact</Link></li>
              <li><Link to="/privacy" className="hover:text-blue-400 transition-colors">Privacy</Link></li>
            </ul>
          </div>
        </div>

        <div className="mt-12 border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-gray-600">
          <p>© {new Date().getFullYear()} Konnectt. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-white transition-colors">Twitter</a>
            <a href="#" className="hover:text-white transition-colors">LinkedIn</a>
            <a href="#" className="hover:text-white transition-colors">GitHub</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
