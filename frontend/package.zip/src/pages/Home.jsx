import React from 'react';
import { useNavigate } from 'react-router-dom';
import FloatingWords from '../components/FloatingWords';

const FeatureCard = ({ icon, title, children }) => (
  <div className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-xl p-6 hover:bg-white/10 transition-all duration-300 group">
    <div className="flex items-start gap-4">
      <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 text-white flex items-center justify-center text-xl group-hover:scale-110 transition-transform duration-300 shadow-lg shadow-blue-500/20">
        {icon}
      </div>
      <div>
        <h4 className="font-bold text-white text-lg">{title}</h4>
        <p className="text-sm text-gray-400 mt-2 leading-relaxed">{children}</p>
      </div>
    </div>
  </div>
);

export default function Home() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white relative overflow-x-hidden">

      {/* Hero Section */}
      <div className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
        {/* Background Gradients */}
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
          <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-purple-600/20 rounded-full blur-[120px]" />
          <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-600/20 rounded-full blur-[120px]" />
        </div>

        {/* Floating Words - Restricted to Hero */}
        <div className="absolute inset-0 z-10">
          <FloatingWords />
        </div>

        <div className="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-block mb-4 px-4 py-1.5 rounded-full border border-white/10 bg-white/5 backdrop-blur-sm text-sm font-medium text-blue-400 animate-fade-in-up">
            🚀 The Future of Hiring is Here
          </div>

          <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight mb-8 leading-tight">
            Find Your <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400">Dream Job</span> <br />
            in the AI Era
          </h1>

          <p className="mt-6 text-xl text-gray-400 max-w-2xl mx-auto leading-relaxed">
            Connect with forward-thinking companies and build your career in the decentralized world.
            AI-powered matching for the next generation of talent.
          </p>

          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-6">
            <button
              onClick={() => navigate('/jobs')}
              className="px-8 py-4 rounded-full bg-gradient-to-r from-blue-600 to-purple-600 text-white font-bold text-lg hover:shadow-lg hover:shadow-blue-500/25 transition-all duration-300 hover:-translate-y-1"
            >
              Explore Opportunities
            </button>
            <button
              onClick={() => navigate('/employer')}
              className="px-8 py-4 rounded-full border border-white/20 bg-white/5 backdrop-blur-sm text-white font-bold text-lg hover:bg-white/10 transition-all duration-300 hover:-translate-y-1"
            >
              Post a Job
            </button>
          </div>

          {/* Stats */}
          <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-8 border-t border-white/10 pt-10">
            {[
              { label: 'Active Jobs', value: '10K+' },
              { label: 'Companies', value: '500+' },
              { label: 'Job Seekers', value: '1M+' },
              { label: 'Countries', value: '50+' },
            ].map((stat, i) => (
              <div key={i}>
                <div className="text-3xl font-bold text-white">{stat.value}</div>
                <div className="text-sm text-gray-500 mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Why Choose Section */}
      <div className="relative py-24 bg-black/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Choose Konnectt?</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Experience a recruitment platform built for the modern world.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <FeatureCard icon={<span>🧠</span>} title="AI-Driven Matching">
              Our neural networks analyze your profile to find opportunities that perfectly align with your skills and career goals.
            </FeatureCard>

            <FeatureCard icon={<span>⚡</span>} title="Instant Connections">
              Skip the queue. Direct messaging with founders and hiring managers at top tech companies.
            </FeatureCard>

            <FeatureCard icon={<span>🛡️</span>} title="Verified Profiles">
              Blockchain-verified credentials ensure trust and transparency for both employers and candidates.
            </FeatureCard>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="relative py-24">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-blue-900/20 pointer-events-none" />
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <div className="bg-gradient-to-r from-gray-900 to-black border border-white/10 rounded-3xl p-12 md:p-20 shadow-2xl shadow-blue-900/20">
            <h2 className="text-3xl md:text-5xl font-bold mb-6">Ready to Shape the Future?</h2>
            <p className="text-xl text-gray-400 mb-10 max-w-2xl mx-auto">
              Join the fastest-growing community of tech professionals and innovators.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button onClick={() => navigate('/register')} className="px-8 py-3 bg-white text-black font-bold rounded-full hover:bg-gray-200 transition-colors">
                Get Started Now
              </button>
              <button onClick={() => navigate('/login')} className="px-8 py-3 border border-white/30 text-white font-bold rounded-full hover:bg-white/10 transition-colors">
                Sign In
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
