import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { authFetch } from '../api';

export default function Jobs() {
  const [jobs, setJobs] = useState([]);
  const [q, setQ] = useState('');
  const [page, setPage] = useState(1);
  const [location, setLocation] = useState('');
  const [remote, setRemote] = useState(false);
  const [minSalary, setMinSalary] = useState('');
  const [maxSalary, setMaxSalary] = useState('');
  const [meta, setMeta] = useState({});

  const token = localStorage.getItem('token');
  const user = JSON.parse(localStorage.getItem('user') || 'null');

  const fetchJobs = async () => {
    const params = new URLSearchParams();
    if (q) params.append('q', q);
    if (location) params.append('location', location);
    if (remote) params.append('remote', 'true');
    if (minSalary) params.append('minSalary', minSalary);
    if (maxSalary) params.append('maxSalary', maxSalary);
    params.append('page', page);

    try {
      const res = await fetch((process.env.REACT_APP_API || 'http://localhost:5000') + '/api/jobs?' + params.toString(), {
        headers: { 'ngrok-skip-browser-warning': 'true' }
      });
      const data = await res.json();
      setJobs(data.data || []);
      setMeta({ page: data.page, total: data.total, totalPages: data.totalPages });
    } catch (error) {
      console.error("Error fetching jobs:", error);
    }
  };

  useEffect(() => {
    fetchJobs();
  }, [q, page, location, remote, minSalary, maxSalary]);

  const apply = async (id) => {
    if (!token) return alert('Login as jobseeker to apply');

    const resumeFile = document.getElementById('resume-file')?.files?.[0];
    let resumeUrl = '';

    if (resumeFile) {
      try {
        const pres = await fetch((process.env.REACT_APP_API || 'http://localhost:5000') + '/api/upload/presign', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token, 'ngrok-skip-browser-warning': 'true' },
          body: JSON.stringify({ filename: resumeFile.name, contentType: resumeFile.type })
        });
        const presData = await pres.json();
        if (!pres.ok) return alert('Could not get upload url');

        await fetch(presData.uploadUrl, {
          method: 'PUT',
          headers: { 'Content-Type': resumeFile.type },
          body: resumeFile
        });
        resumeUrl = presData.publicUrl;
      } catch (error) {
        console.error("Upload error:", error);
        return alert('Error uploading resume');
      }
    }

    const cover = prompt('Write a short cover letter (optional)');
    if (cover === null) return; // User cancelled

    try {
      const res = await fetch((process.env.REACT_APP_API || 'http://localhost:5000') + `/api/jobs/${id}/apply`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token, 'ngrok-skip-browser-warning': 'true' },
        body: JSON.stringify({ coverLetter: cover, resumeUrl })
      });
      const data = await res.json();
      if (res.ok) alert('Applied successfully');
      else alert(data.error || 'Error');
    } catch (error) {
      console.error("Apply error:", error);
      alert('Failed to apply');
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] py-10 pt-24 text-white relative overflow-hidden">
      {/* Background Gradients */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0 pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-purple-600/10 rounded-full blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-600/10 rounded-full blur-[120px]" />
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">

        {/* Header */}
        <div className="mb-10 text-center">
          <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight mb-4">
            Browse <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400">Opportunities</span>
          </h1>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg">
            Find your next career move in the decentralized world.
          </p>
        </div>

        {/* Filters */}
        <div className="bg-white/5 backdrop-blur-lg border border-white/10 p-6 rounded-2xl shadow-xl mb-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <input
              type="text"
              placeholder="Search by title or company..."
              value={q}
              onChange={e => setQ(e.target.value)}
              className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
            />
            <input
              type="text"
              placeholder="Location"
              value={location}
              onChange={e => setLocation(e.target.value)}
              className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
            />
            <div className="flex items-center gap-3 px-4 bg-black/40 border border-white/10 rounded-xl">
              <input
                type="checkbox"
                id="remote"
                checked={remote}
                onChange={e => setRemote(e.target.checked)}
                className="w-5 h-5 text-blue-600 bg-gray-900 border-gray-600 rounded focus:ring-blue-500 focus:ring-offset-gray-900"
              />
              <label htmlFor="remote" className="text-gray-300 font-medium cursor-pointer select-none">Remote Only</label>
            </div>
            <input
              type="number"
              placeholder="Min Salary (INR)"
              value={minSalary}
              onChange={e => setMinSalary(e.target.value)}
              className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
            />
            <input
              type="number"
              placeholder="Max Salary (INR)"
              value={maxSalary}
              onChange={e => setMaxSalary(e.target.value)}
              className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
            />
            <button
              onClick={() => { setPage(1); fetchJobs(); }}
              className="w-full px-4 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-blue-500/25 transition-all transform hover:-translate-y-0.5"
            >
              Apply Filters
            </button>
          </div>
        </div>

        {/* Resume Upload (Hidden/Utility) */}
        <div className="mb-6 hidden">
          <label className="block text-sm font-medium text-gray-400 mb-2">Upload Resume (Optional for application)</label>
          <input
            id="resume-file"
            type="file"
            className="block w-full text-sm text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-600 file:text-white hover:file:bg-blue-700"
          />
        </div>

        {/* Job List */}
        <div className="space-y-4">
          {jobs.length === 0 ? (
            <div className="text-center py-20">
              <div className="text-6xl mb-4">🔍</div>
              <p className="text-gray-400 text-lg">No jobs found matching your criteria.</p>
            </div>
          ) : (
            jobs.map(j => (
              <div key={j._id} className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all duration-300 group hover:border-blue-500/30 hover:shadow-lg hover:shadow-blue-500/10">
                <div className="flex flex-col md:flex-row justify-between items-start gap-4">
                  <div className="flex-1">
                    <Link to={`/jobs/${j._id}`} className="group-hover:text-blue-400 transition-colors">
                      <h3 className="text-2xl font-bold text-white mb-1">{j.title}</h3>
                    </Link>
                    <p className="text-gray-400 font-medium text-lg mb-3">{j.company}</p>

                    <div className="flex flex-wrap gap-3 text-sm text-gray-300 mb-4">
                      <span className="flex items-center gap-1.5 bg-white/5 px-3 py-1 rounded-full border border-white/5">
                        📍 {j.location}
                      </span>
                      <span className="flex items-center gap-1.5 bg-white/5 px-3 py-1 rounded-full border border-white/5">
                        💰 {j.salaryText || 'Salary not specified'}
                      </span>
                      <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${j.remote ? 'bg-green-500/20 text-green-400 border border-green-500/20' : 'bg-blue-500/20 text-blue-400 border border-blue-500/20'}`}>
                        {j.remote ? 'Remote' : 'On-site'}
                      </span>
                    </div>

                    <p className="text-gray-400 line-clamp-2 leading-relaxed">{j.description}</p>
                  </div>

                  <div className="flex flex-row md:flex-col gap-3 w-full md:w-auto mt-4 md:mt-0">
                    <Link
                      to={`/jobs/${j._id}`}
                      className="flex-1 md:flex-none px-6 py-2.5 border border-white/20 text-white text-center font-medium rounded-xl hover:bg-white/10 transition-all"
                    >
                      Details
                    </Link>
                    {user?.role === 'jobseeker' && (
                      <button
                        onClick={() => apply(j._id)}
                        className="flex-1 md:flex-none px-6 py-2.5 bg-white text-black text-center font-bold rounded-xl hover:bg-gray-200 transition-all shadow-lg shadow-white/5"
                      >
                        Apply
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Pagination */}
        <div className="mt-12 flex justify-center items-center gap-6">
          <button
            onClick={() => setPage(p => Math.max(1, p - 1))}
            disabled={page === 1}
            className="px-6 py-2.5 border border-white/20 rounded-xl text-white font-medium disabled:opacity-30 disabled:cursor-not-allowed hover:bg-white/10 transition-all"
          >
            Previous
          </button>
          <span className="text-gray-400 font-medium">
            Page <span className="text-white">{meta.page || 1}</span> of <span className="text-white">{meta.totalPages || 1}</span>
          </span>
          <button
            onClick={() => setPage(p => p + 1)}
            disabled={page >= (meta.totalPages || 1)}
            className="px-6 py-2.5 border border-white/20 rounded-xl text-white font-medium disabled:opacity-30 disabled:cursor-not-allowed hover:bg-white/10 transition-all"
          >
            Next
          </button>
        </div>

      </div>
    </div>
  );
}
