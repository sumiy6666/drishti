import React, { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';

export default function JobDetails() {
    const { id } = useParams();
    const navigate = useNavigate();
    const [job, setJob] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [applying, setApplying] = useState(false);
    const [coverLetter, setCoverLetter] = useState('');
    const [resumeUrl, setResumeUrl] = useState('');
    const [applicationStatus, setApplicationStatus] = useState(null); // 'success', 'error', null

    const userStr = localStorage.getItem('user');
    const user = userStr ? JSON.parse(userStr) : null;

    useEffect(() => {
        if (user && user.resume) {
            setResumeUrl(user.resume);
        }
    }, []);

    useEffect(() => {
        const fetchJob = async () => {
            try {
                const res = await fetch((process.env.REACT_APP_API || 'http://localhost:5000') + '/api/jobs/' + id, {
                    headers: { 'ngrok-skip-browser-warning': 'true' }
                });
                if (!res.ok) throw new Error('Job not found');
                const data = await res.json();
                setJob(data);
            } catch (err) {
                setError(err.message);
            } finally {
                setLoading(false);
            }
        };
        fetchJob();
    }, [id]);

    const handleApply = async (e) => {
        e.preventDefault();
        if (!user) {
            navigate('/login');
            return;
        }

        setApplying(true);
        try {
            const token = localStorage.getItem('token');
            const res = await fetch((process.env.REACT_APP_API || 'http://localhost:5000') + `/api/jobs/${id}/apply`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + token,
                    'ngrok-skip-browser-warning': 'true'
                },
                body: JSON.stringify({ coverLetter, resumeUrl })
            });

            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Failed to apply');

            setApplicationStatus('success');
            setCoverLetter('');
            setResumeUrl('');
        } catch (err) {
            setApplicationStatus('error');
            alert(err.message);
        } finally {
            setApplying(false);
        }
    };

    if (loading) return <div className="min-h-screen flex items-center justify-center bg-[#0a0a0a]"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div></div>;
    if (error || !job) return <div className="min-h-screen flex items-center justify-center bg-[#0a0a0a] text-red-500 font-medium">Error: {error || 'Job not found'}</div>;

    return (
        <div className="min-h-screen bg-[#0a0a0a] py-12 px-4 sm:px-6 lg:px-8 pt-24 text-white relative overflow-hidden">
            {/* Background Gradients */}
            <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0 pointer-events-none">
                <div className="absolute top-[-10%] right-[-10%] w-[40%] h-[40%] bg-purple-600/10 rounded-full blur-[120px]" />
                <div className="absolute bottom-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-600/10 rounded-full blur-[120px]" />
            </div>

            <div className="max-w-4xl mx-auto relative z-10">

                {/* Back Button */}
                <Link to="/jobs" className="inline-flex items-center text-gray-400 hover:text-white mb-8 transition-colors group">
                    <span className="mr-2 group-hover:-translate-x-1 transition-transform">←</span> Back to Jobs
                </Link>

                {/* Header Card */}
                <div className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-3xl p-8 mb-8 relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-blue-500/10 to-purple-500/10 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none"></div>

                    <div className="relative z-10">
                        <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
                            <div>
                                <h1 className="text-4xl font-bold text-white mb-2 tracking-tight">{job.title}</h1>
                                <div className="flex items-center gap-3 text-xl text-gray-300 font-medium mb-6">
                                    <span className="text-blue-400">{job.company}</span>
                                    <span className="text-gray-600">•</span>
                                    <span>{job.location}</span>
                                </div>

                                <div className="flex flex-wrap gap-3">
                                    <span className="px-4 py-1.5 bg-blue-500/10 text-blue-400 border border-blue-500/20 rounded-full text-sm font-medium">
                                        {job.remote ? 'Remote' : 'On-site'}
                                    </span>
                                    <span className="px-4 py-1.5 bg-green-500/10 text-green-400 border border-green-500/20 rounded-full text-sm font-medium">
                                        {job.salaryText || `${job.salaryMin?.toLocaleString()} - ${job.salaryMax?.toLocaleString()}`}
                                    </span>
                                    <span className="px-4 py-1.5 bg-purple-500/10 text-purple-400 border border-purple-500/20 rounded-full text-sm font-medium">
                                        Full-time
                                    </span>
                                </div>
                            </div>

                            {user?.role === 'jobseeker' && !applicationStatus && (
                                <a href="#apply-section" className="px-8 py-4 bg-white text-black font-bold rounded-2xl hover:bg-gray-200 transition-all shadow-lg hover:shadow-white/10 transform hover:-translate-y-1 text-center">
                                    Apply Now
                                </a>
                            )}
                            {user?.role === 'employer' && user._id === job.employer?._id && (
                                <Link to={`/jobs/${id}/applications`} className="px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-bold rounded-2xl hover:shadow-lg hover:shadow-blue-500/25 transition-all transform hover:-translate-y-1 text-center">
                                    View Applicants
                                </Link>
                            )}
                        </div>
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {/* Main Content */}
                    <div className="md:col-span-2 space-y-8">

                        {/* Description */}
                        <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-3xl p-8">
                            <h2 className="text-2xl font-bold text-white mb-6">Job Description</h2>
                            <div className="prose prose-invert max-w-none text-gray-300 leading-relaxed whitespace-pre-line">
                                {job.description}
                            </div>
                        </div>

                        {/* Skills */}
                        <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-3xl p-8">
                            <h2 className="text-2xl font-bold text-white mb-6">Required Skills</h2>
                            <div className="flex flex-wrap gap-3">
                                {job.skills && job.skills.map((skill, index) => (
                                    <span key={index} className="px-4 py-2 bg-white/5 text-gray-300 rounded-xl text-sm font-medium border border-white/10 hover:border-white/30 transition-colors">
                                        {skill}
                                    </span>
                                ))}
                            </div>
                        </div>

                        {/* Custom Fields */}
                        {job.customFields && job.customFields.length > 0 && (
                            <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-3xl p-8">
                                <h2 className="text-2xl font-bold text-white mb-6">Additional Details</h2>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    {job.customFields.map((field, index) => (
                                        <div key={index} className="bg-white/5 p-4 rounded-xl border border-white/5">
                                            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">{field.label}</h3>
                                            <p className="text-white font-medium">{field.value}</p>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}

                    </div>

                    {/* Sidebar */}
                    <div className="space-y-8">

                        {/* Company Info */}
                        <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-3xl p-8">
                            <h3 className="text-xl font-bold text-white mb-6">About the Company</h3>
                            <div className="flex items-center gap-4 mb-6">
                                <div className="w-14 h-14 bg-gradient-to-br from-gray-800 to-black border border-white/10 rounded-2xl flex items-center justify-center text-2xl font-bold text-white shadow-lg">
                                    {job.company.charAt(0)}
                                </div>
                                <div>
                                    <h4 className="font-bold text-white text-lg">{job.company}</h4>
                                    <p className="text-sm text-gray-500">Technology</p>
                                </div>
                            </div>
                            <p className="text-sm text-gray-400 leading-relaxed">
                                We are a forward-thinking company dedicated to innovation and excellence. Join our team to make a real impact.
                            </p>
                        </div>

                        {/* Application Form */}
                        {user?.role === 'jobseeker' && (
                            <div id="apply-section" className="bg-white/5 backdrop-blur-md border border-white/10 rounded-3xl p-8">
                                <h3 className="text-xl font-bold text-white mb-6">Apply for this Job</h3>

                                {applicationStatus === 'success' ? (
                                    <div className="bg-green-500/10 border border-green-500/20 text-green-400 p-6 rounded-2xl text-center">
                                        <div className="text-4xl mb-3">🎉</div>
                                        <p className="font-bold text-lg mb-1">Application Sent!</p>
                                        <p className="text-sm opacity-80">Good luck! You can track this in "My Applications".</p>
                                    </div>
                                ) : (
                                    <form onSubmit={handleApply} className="space-y-5">
                                        <div>
                                            <label className="block text-sm font-medium text-gray-400 mb-2">Resume URL</label>
                                            <input
                                                type="url"
                                                required
                                                placeholder="Link to your resume (Drive, LinkedIn...)"
                                                className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-white placeholder-gray-600 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                                                value={resumeUrl}
                                                onChange={e => setResumeUrl(e.target.value)}
                                            />
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium text-gray-400 mb-2">Cover Letter</label>
                                            <textarea
                                                rows="4"
                                                placeholder="Why are you a good fit?"
                                                className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-white placeholder-gray-600 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                                                value={coverLetter}
                                                onChange={e => setCoverLetter(e.target.value)}
                                            ></textarea>
                                        </div>
                                        <button
                                            type="submit"
                                            disabled={applying}
                                            className="w-full py-4 bg-white text-black font-bold rounded-xl hover:bg-gray-200 transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-white/5"
                                        >
                                            {applying ? 'Sending...' : 'Submit Application'}
                                        </button>
                                    </form>
                                )}
                            </div>
                        )}

                        {!user && (
                            <div className="bg-blue-500/10 border border-blue-500/20 rounded-3xl p-8 text-center">
                                <p className="text-blue-400 font-medium mb-4">Login to apply for this position</p>
                                <Link to="/login" className="inline-block px-8 py-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors text-sm font-bold shadow-lg shadow-blue-500/20">
                                    Login Now
                                </Link>
                            </div>
                        )}

                    </div>
                </div>

            </div>
        </div>
    );
}
